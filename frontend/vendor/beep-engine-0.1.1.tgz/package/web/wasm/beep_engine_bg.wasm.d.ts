/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const crashSound: (a: number) => [number, number, number, number];
export const startupBeep: (a: number) => [number, number, number, number];
export const __wbindgen_externrefs: WebAssembly.Table;
export const __externref_table_dealloc: (a: number) => void;
export const __wbindgen_free: (a: number, b: number, c: number) => void;
export const __wbindgen_start: () => void;
